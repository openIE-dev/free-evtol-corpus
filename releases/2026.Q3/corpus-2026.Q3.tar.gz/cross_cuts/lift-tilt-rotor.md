---
title: lift-tilt-rotor
parent: Cross-cuts
layout: default
---

# Cross-cut: `lift-tilt-rotor`

**19 corpus entries disclose this subsystem.**

Earliest disclosure: 1959-06-15

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## Kamov Ka-22 Vintokryl (1959-06-15)

- **id**: `kamov-ka-22-vintokryl`
- **corpus**: academic
- **creator**: Kamov Design Bureau (OKB-2)
- **disclosure**: Ka-22 Vintokryl first hover 1959-06-15; first transition flight 1961-08-12. Set FAI world records 1961-11-07 (speed 356.3 km/h, payload-to-altitude 16,485 kg). Documented in Mikheyev's history of Kamov design bureau and in FAI record archives.
- **ip status**: public-domain
- **prior art notes**: The Ka-22 Vintokryl is the Soviet contemporaneous answer to U.S. tilt-rotor demonstrators. Establishes Soviet-bloc prior art (1959–1961) for: (1) wingtip-mounted lift-rotor + cruise-propeller architecture (parallel to but predating Bell XV-3 and XV-15 in some configurations), (2) record-setting heavy-payload VTOL operation. Soviet design documentation, declassified in the post-1991 era, is in the public domain by virtue of being USSR state work. Provides invalidity anchor for tilt-rotor-with-cruise-propeller hybrid claims that try to assert novelty over the basic split-propulsion approach.

## Bell XV-15 (1977-05-03)

- **id**: `bell-xv-15`
- **corpus**: academic
- **creator**: Bell Helicopter / NASA / U.S. Army
- **disclosure**: Bell XV-15 first hover flight 1977-05-03 at Bell Helicopter Arlington; first full transition 1979-07-24. Documented exhaustively in NASA SP-2000-4517, 'The History of the XV-15 Tilt Rotor Research Aircraft' (Maisel, Giulianetti, Dugan).
- **ip status**: public-domain
- **prior art notes**: The XV-15 is the foundational disclosure for the modern tilt-rotor architecture that now dominates the eVTOL air-taxi design space (Joby S4, Archer Midnight, Vertical VX4, Beta Alia tilt-cruise variants all descend from this geometry). Establishes prior art for: (1) wingtip-mounted gimbaled prop-rotor with cyclic and collective blade pitch, (2) the conversion-corridor envelope explicitly mapped and published by Bell/NASA, (3) cross-shafted twin-engine drive of dual prop-rotors with engine-out lift continuation, (4) coordinated nacelle tilt with thrust vector for transition control. Hundreds of NASA reports document the design completely. Filed against any post-1977 tilt-rotor patent claim, this entry is a canonical 102/103 anchor. The XV-15 directly precedes the V-22 Osprey (descended program) and the entire current generation of commercial eVTOL tilt-rotors.

## Mil Mi-30 (1985-03)

- **id**: `mil-mi-30`
- **corpus**: academic
- **creator**: Mil Moscow Helicopter Plant
- **disclosure**: Mil Mi-30 design specification approved by Soviet Ministry of Aviation Industry March 1985; multiple wind-tunnel and design studies completed; cancelled after Soviet collapse 1991 before any prototype built. Design materials in Mil OKB declassified archives.
- **ip status**: public-domain
- **prior art notes**: The Mi-30 is the Soviet/Russian tilt-rotor program — designed but not built before USSR dissolution. Establishes Soviet prior-art lineage for tilt-rotor architecture in heavy military configuration (parallel to V-22 development). Combined with kamov-ka-22-vintokryl (1959) and Mi-30 (1985), Soviet/Russian tilt-rotor / convertiplane design materials cover three decades and are comprehensively in the public domain.

## V-22 Osprey (1989-03-19)

- **id**: `v-22-osprey`
- **corpus**: private
- **creator**: Bell Helicopter / Boeing / U.S. Marine Corps / U.S. Air Force
- **disclosure**: V-22 Osprey first flight 1989-03-19 at Bell Flight Research Center, Arlington TX; full operational capability declared 2007. Aircraft and engineering disclosures published exhaustively in NAVAIR / Marine Corps reports and in Norton's Bell-Boeing V-22 Osprey volume.
- **ip status**: patented
- **prior art notes**: The V-22 Osprey is the production tilt-rotor that brought XV-15 prior art into operational service. Establishes prior art for: (1) production-grade triplex fly-by-wire tilt-rotor flight control, (2) cross-shafted prop-rotor drive with single-engine emergency operation in hover, (3) the operational conversion corridor with explicit nacelle-angle commanded transition. Bell's V-22-era tilt-rotor patents are largely now expired (most filed 1985–1995, 20-year terms). Together with XV-15, comprehensively places production tilt-rotor architecture in the public domain. Joby, Archer, and Vertical Aerospace's tilt-rotor claims are anticipated by V-22 disclosures where they overlap on architecture rather than electric-specific actuation.

## Section 9 Tilt-Rotor (Ghost in the Shell) (1989-05)

- **id**: `ghost-in-the-shell-tiltrotor`
- **corpus**: fictional
- **creator**: Masamune Shirow / Mamoru Oshii / Production I.G
- **disclosure**: Ghost in the Shell (攻殻機動隊 Kōkaku Kidōtai) manga first appearance Young Magazine, May 1989; Mamoru Oshii anime film 1995-11-18 with highly-detailed tilt-rotor police craft. Subsequent disclosures in Stand Alone Complex (2002) and Innocence (2004) animations and associated visual-design books.
- **ip status**: fictional
- **prior art notes**: Ghost in the Shell's Section 9 tilt-rotor is among the most engineering-detailed fictional tilt-rotor depictions. Production I.G design books (multiple editions) include schematic-grade illustrations. Establishes additional Japanese fictional prior art for civilian/police tilt-rotor passenger transport, complementing macross-vf-1-veritech (1982).

## Leonardo AW609 (2003-03-06)

- **id**: `leonardo-aw609`
- **corpus**: private
- **creator**: Bell Helicopter / Agusta / AgustaWestland / Leonardo S.p.A.
- **disclosure**: Bell/Agusta BA609 first flight 2003-03-06 at Bell Flight Research Center, Arlington TX (joint US-Italian program); program transferred to AgustaWestland 2011, renamed AW609; type certification target FAA Part 29 civil tilt-rotor with anticipated TC 2025-2026. Multiple Bell and Leonardo patents publicly filed.
- **ip status**: patented
- **prior art notes**: The AW609 is the world's first civil-certified tilt-rotor aircraft, intended to enter service circa 2026. Direct architectural descendant of Bell XV-15 and V-22 Osprey, scaled and adapted for civil Part 29 operation with a pressurized cabin. Establishes Italian/European industrial prior-art lineage for civil tilt-rotor commercialization. Joby S4, Archer Midnight, and other commercial eVTOL tilt-rotor claims are anticipated by AW609's documented design and certification basis.

## Bell Eagle Eye TR918 (2003-03-06)

- **id**: `bell-eagle-eye`
- **corpus**: private
- **creator**: Bell Helicopter Textron / U.S. Coast Guard / U.S. Army
- **disclosure**: Bell Eagle Eye first hover 2003-03-06; first transition flight 2003-08-22; full-scale TR918 unveiled at HAI Heli-Expo 2005. U.S. Coast Guard Deepwater program cancellation 2007 ended production but Bell continues design work. Documented in Bell technical papers and Coast Guard procurement records.
- **ip status**: patented
- **prior art notes**: Bell Eagle Eye is the unmanned-scale tilt-rotor descended from the V-22 program — establishes prior art for: (1) tilt-rotor architecture in unmanned tactical UAV scale, (2) autonomous tilt-rotor mission operation. Together with bell-xv-15, v-22-osprey, bell-v-280-valor, and aerovironment-skytote, places tilt-rotor architecture across the full scale spectrum from small unmanned to large troop transport in comprehensive prior-art coverage.

## Karem AR40 / Optimum Speed Tilt-Rotor (2008)

- **id**: `karem-ar40`
- **corpus**: private
- **creator**: Karem Aircraft Inc (Lake Forest, California)
- **disclosure**: Karem Aircraft AR40 / Optimum Speed Tilt-Rotor concept publicly disclosed in U.S. Army FVL program documentation 2008-2010; AR40 design materials in DARPA / Army Heavy Lift program filings. Karem holds Optimum Speed Rotor patents covering variable-RPM rotor operation.
- **ip status**: patented
- **prior art notes**: Karem AR40 establishes prior art for: (1) variable-RPM Optimum Speed Rotor technology (continuously varying rotor RPM with forward speed and altitude for fuel-burn optimization), (2) very-large-payload tilt-rotor architecture. Karem's slowed-rotor patents are cited as prior art in Joby and Archer patent filings around variable-RPM rotor operation. Anticipates modern eVTOL claims around variable-RPM operation for efficiency optimization.

## Samson and Scorpion (Avatar) (2009-12-18)

- **id**: `avatar-samson-scorpion`
- **corpus**: fictional
- **creator**: James Cameron / Lightstorm Entertainment / 20th Century Fox
- **disclosure**: Avatar (Avatar: The Way of Water and sequels), directed by James Cameron, theatrical release 2009-12-18. Production designer Robert Stromberg and concept artists at Lightstorm developed detailed engineering depictions of the AT-99 Scorpion and SA-2 Samson, documented in The Art of Avatar (Abrams, 2009).
- **ip status**: fictional
- **prior art notes**: Avatar's Scorpion and Samson tilt-rotor gunships establish 2009 fictional cinematic prior art for military tilt-rotor architecture. Production-designed depictions in The Art of Avatar include detailed cutaway schematics. Combined with macross-vf-1-veritech (1982), ghost-in-the-shell-tiltrotor (1989), and bell-xv-15 (1977), provides multi-decade tilt-rotor prior art across both academic / military / commercial real-world programs and fictional cinematic depictions.

## Wingcopter 198 (2017-04-26)

- **id**: `wingcopter-198`
- **corpus**: private
- **creator**: Wingcopter GmbH (Weiterstadt, Germany)
- **disclosure**: Wingcopter founded 2017-04-26; Wingcopter 178 first commercial flights 2018-09 (vaccine delivery to Vanuatu islands with UNICEF); Wingcopter 198 production-design unveiled 2020-04-21. EU type certification (CS-LURS / EASA Special Condition) in process. Wingcopter holds the Tilt-Rotor Mechanism patent family (EP3260370, US10913529).
- **ip status**: patented
- **prior art notes**: Wingcopter 198 is Germany's lead unmanned tilt-rotor cargo eVTOL — operational since 2018 (medical delivery to Pacific islands with UNICEF). Establishes prior art for: (1) small-airframe tilt-rotor cargo eVTOL with single-axis tilt mechanism (Wingcopter Tilt-Rotor Mechanism patent family), (2) the cargo / payload-delivery use case for tilt-rotor eVTOL distinct from passenger air taxi. Anticipates cargo eVTOL claims asserting novelty over single-axis tilt actuation.

## Bell V-280 Valor (2017-12-18)

- **id**: `bell-v-280-valor`
- **corpus**: private
- **creator**: Bell Textron / U.S. Army
- **disclosure**: Bell V-280 Valor first flight 2017-12-18 at Amarillo TX; selected by U.S. Army for Future Long Range Assault Aircraft (FLRAA) program 2022-12-05 over Sikorsky-Boeing Defiant X. Documented in Bell Textron technical papers, U.S. Army FLRAA program reports, and patent filings.
- **ip status**: patented
- **prior art notes**: Bell V-280 Valor establishes the third-generation tilt-rotor architecture: distinct from XV-15 and V-22 by tilting the prop-rotors via tilt-shaft while the engine nacelles remain fixed. Cuts complexity and reduces engine wear from rotation. Valor's selection for FLRAA (2022) makes it the production-track future of U.S. Army tilt-rotor operations. Establishes prior art for: (1) fixed-nacelle tilt-shaft prop-rotor architecture, (2) the next-generation tilt-rotor flight envelope (280+ kt cruise, 2,200 km range).

## ASKA A5 (2018)

- **id**: `aska-a5`
- **corpus**: private
- **creator**: ASKA / NFT Inc (Mountain View, California / Nagoya, Japan)
- **disclosure**: ASKA / NFT Inc founded 2018 by Guy Kaplinsky and Maki Kaplinsky; A5 production-design unveiled at CES 2023 (2023-01-04); FAA Special Airworthiness Certificate (Experimental) granted 2023-06-29 for flight testing. NHTSA-approved street-legal road operation pending.
- **ip status**: patented
- **prior art notes**: ASKA A5 is the leading drive+fly transformer eVTOL with documented FAA experimental-category certification. Establishes prior art for: (1) folding-wing tilt-rotor transformer architecture, (2) hybrid-electric powerplant for transformer range extension, (3) dual-certification basis (FAA + NHTSA road-legal). Anticipates: PAL-V Liberty, AeroMobil 4.0, Klein Vision AirCar, and any modern drive+fly patent claim.

## Joby Aviation S4 (2018-12-20)

- **id**: `joby-s4`
- **corpus**: private
- **creator**: Joby Aviation
- **disclosure**: Joby S4 unveiling and first flight: Joby first publicly disclosed S4 prototype 2018-12-20 (Joby press release); first untethered transition flight 2017-08 (predecessor S2); S4 Production Prototype first transition flight reported in Joby Aviation S-1 SEC filing 2020-08, full disclosure in 10-K filings 2021–2025.
- **ip status**: patented
- **prior art notes**: The Joby S4 is the lead commercial tilt-rotor electric eVTOL. Direct architectural descendant of bell-xv-15 (1977) and v-22-osprey (1989) — Joby's tilt geometry, conversion corridor, and gimbaled prop-rotor topology are classical tilt-rotor architecture with electric distributed propulsion substituted for cross-shafted turboshaft. Establishes prior art for: (1) six-rotor tilt-rotor with stop-in-cruise props, (2) BLDC direct-drive tilt-rotor propulsion, (3) Part 23 SVO certification basis. Joby's patent estate (US 10,994,841 et seq.) covers specific implementations but is anticipated on the architectural level by XV-15 and V-22 disclosures.

## Manta Aircraft ANN2 (2020-04)

- **id**: `manta-aircraft-ann2`
- **corpus**: private
- **creator**: Manta Aircraft S.A. (Lugano, Switzerland / Varese, Italy)
- **disclosure**: Manta Aircraft ANN2 design publicly unveiled April 2020 at AERO Friedrichshafen; sub-scale prototype hover testing 2021. Manta Aircraft founded 2018 by Lucas Marchesini (Italian-Swiss aerospace engineer).
- **ip status**: patented
- **prior art notes**: Manta Aircraft ANN2 is the lead Italian-Swiss commercial eVTOL — hybrid-electric tilt-rotor with twin-fuselage geometry. Adds Italian prior-art lineage for hybrid-electric eVTOL alongside Leonardo AW609 (production tilt-rotor) and complements the Slovak (Klein Vision, AeroMobil) and Dutch (PAL-V) drive+fly Central European base.

## Archer Aviation Midnight (2021-06-10)

- **id**: `archer-midnight`
- **corpus**: private
- **creator**: Archer Aviation
- **disclosure**: Archer Aviation S-1 SEC filing 2021-06-10; Archer Midnight design publicly unveiled 2022-11-16; Maker demonstrator first hover flight 2021-12; first full transition 2023-06.
- **ip status**: patented
- **prior art notes**: Archer Midnight is a hybrid lift+cruise / tilt-rotor architecture with six tilting and six lift-only propellers. Architecturally descends from the NASA GL-10 DEP tilt-wing concept and the XV-15 tilt-rotor, with the lift+cruise split providing lower hover-prop disk loading at the cost of cruise drag from idle lift props. Disclosures in SEC filings make this a commons-grade entry. Establishes prior art for: (1) 6+6 hybrid tilt-and-lift-only DEP architecture, (2) feathering cruise props with fixed-cruise disk.

## Geely Aerofugia AE200 (2021-09-14)

- **id**: `geely-aerofugia-ae200`
- **corpus**: private
- **creator**: Aerofugia (Geely Holding Group eVTOL subsidiary)
- **disclosure**: Geely Holding Group launched Aerofugia subsidiary 2021-09-14 in Chengdu; AE200 design publicly unveiled at Beijing Air Show 2022-02-10; sub-scale prototype hover 2023-04. Geely also acquired Terrafugia (US) 2017-11 and uses combined IP base for AE200.
- **ip status**: patented
- **prior art notes**: Geely Aerofugia AE200 is China's third major commercial passenger eVTOL (with EHang and AutoFlight). Distinctive: Geely's parallel ownership of Terrafugia (US flying car company since 2017) provides cross-Pacific patent integration. Establishes additional Chinese tilt-rotor prior-art lineage alongside TCab E20.

## Vertical Aerospace VX4 (2021-09-29)

- **id**: `vertical-vx4`
- **corpus**: private
- **creator**: Vertical Aerospace Ltd (Bristol, United Kingdom)
- **disclosure**: Vertical Aerospace VX4 unveiled 2021-09-29 at SPAC announcement / investor presentation; first tethered hover 2022-09-26; first untethered transition 2024-12. SPAC merger with Broadstone Acquisition (NYSE: EVTL) completed 2021-12. Lead investors include Microsoft / Avolon / American Airlines / Honeywell / Rolls-Royce.
- **ip status**: patented
- **prior art notes**: Vertical Aerospace VX4 is the United Kingdom's lead commercial eVTOL — the post-Hawker British vectored/tilt VTOL inheritance translated into electric propulsion. The 4+4 tilt-and-lift hybrid is architecturally between Joby S4 (6 tilt) and Archer Midnight (6+6 hybrid). Establishes UK prior-art lineage for commercial tilt-rotor eVTOL; Rolls-Royce propulsion subsystem involvement provides direct industrial-scale supplier coverage.

## TCab Tech E20 (2022-12-07)

- **id**: `tcab-tech-e20`
- **corpus**: private
- **creator**: TCab Tech (Shanghai TCab)
- **disclosure**: TCab Tech E20 sub-scale technology demonstrator first transition flight 2022-12-07 at Tianjin; full-scale E20 prototype unveiled 2023-09-13. TCab founded 2021 in Shanghai by Yon Wui Ng; technical leadership from former Volocopter and Lilium engineers.
- **ip status**: patented
- **prior art notes**: TCab Tech E20 is China's lead tilt-rotor passenger eVTOL — architectural sibling to Joby S4 with the same 4+2 tilt-rotor configuration. Establishes Chinese-lineage prior art for the tilt-rotor electric eVTOL category, ensuring the architectural pattern is disclosed across at least four geographic prior-art bases (US, EU, China, Italy).

## Hyundai Supernal S-A2 (2024-01-09)

- **id**: `hyundai-supernal-sa2`
- **corpus**: private
- **creator**: Supernal LLC (Hyundai Motor Group eVTOL subsidiary)
- **disclosure**: Hyundai Supernal S-A2 unveiled at CES 2024 (Las Vegas), 2024-01-09. Predecessor S-A1 design unveiled at CES 2020 (2020-01-07). Supernal LLC incorporated under Hyundai Motor Group, headquartered in Washington DC with engineering in Irvine CA, but the design lineage and corporate ownership are South Korean.
- **ip status**: patented
- **prior art notes**: Hyundai Supernal S-A2 is Korea's lead commercial eVTOL program, backed by Hyundai Motor Group's automotive industrial scale. The 4+4 tilt-rotor configuration is architecturally between Joby S4 (4+2) and tilt-wing designs. Establishes Korean prior-art lineage for tilt-rotor commercial eVTOL; targets FAA Part 23 certification and 2028 commercial operation.
