---
title: airframe-composite-monocoque
parent: Cross-cuts
layout: default
---

# Cross-cut: `airframe-composite-monocoque`

**41 corpus entries disclose this subsystem.**

Earliest disclosure: 1978-11-09

Listed in chronological order. Each entry's `prior_art_notes` and
`disclosure_citation` constitute the citeable prior art material.

---

## McDonnell Douglas / BAe AV-8B Harrier II (1978-11-09)

- **id**: `av-8b-harrier-ii`
- **corpus**: private
- **creator**: McDonnell Douglas / British Aerospace / U.S. Marine Corps / Royal Air Force
- **disclosure**: AV-8B prototype YAV-8B first flight 1978-11-09 at McDonnell Douglas St. Louis (modified Harrier GR.1 airframe); production AV-8B first flight 1981-11-05; entered USMC service 1985. Joint U.S.-U.K. production program (RAF Harrier GR.5 / GR.7 / GR.9 variants). Documented in U.S. Navy / RAF technical orders, McDonnell Douglas / Boeing technical papers, and Smithsonian collections.
- **ip status**: patented
- **prior art notes**: AV-8B Harrier II is the production-definitive vectored-thrust VTOL fighter — second-generation development of the P.1127/Harrier lineage with supercritical wing and lift-improvement devices that nearly doubled payload over Harrier GR.1. The U.S. Marine Corps operated AV-8B from 1985 through 2014 (replaced by F-35B), and the RAF operated GR.5/7/9 variants 1989-2010 — comprehensive multi-decade operational disclosure of the production-scale Pegasus four-poster vectored-thrust architecture. Most McDonnell Douglas / Boeing AV-8B-era patents have now expired (filed 1975-2000). Combined with hawker-p-1127 (1960), hawker-siddeley-harrier (1967), and f-35b-lightning (2008), comprehensively places vectored-thrust VTOL fighter architecture in 50+ years of public-domain prior art.

## Leonardo AW609 (2003-03-06)

- **id**: `leonardo-aw609`
- **corpus**: private
- **creator**: Bell Helicopter / Agusta / AgustaWestland / Leonardo S.p.A.
- **disclosure**: Bell/Agusta BA609 first flight 2003-03-06 at Bell Flight Research Center, Arlington TX (joint US-Italian program); program transferred to AgustaWestland 2011, renamed AW609; type certification target FAA Part 29 civil tilt-rotor with anticipated TC 2025-2026. Multiple Bell and Leonardo patents publicly filed.
- **ip status**: patented
- **prior art notes**: The AW609 is the world's first civil-certified tilt-rotor aircraft, intended to enter service circa 2026. Direct architectural descendant of Bell XV-15 and V-22 Osprey, scaled and adapted for civil Part 29 operation with a pressurized cabin. Establishes Italian/European industrial prior-art lineage for civil tilt-rotor commercialization. Joby S4, Archer Midnight, and other commercial eVTOL tilt-rotor claims are anticipated by AW609's documented design and certification basis.

## Urban Aeronautics CityHawk (2009-12-21)

- **id**: `urban-aero-cityhawk`
- **corpus**: private
- **creator**: Urban Aeronautics Ltd (Yavne, Israel)
- **disclosure**: Urban Aeronautics' X-Hawk / AirMule first untethered hover 2009-12-21 at Megiddo airfield, Israel; CityHawk civil variant unveiled 2018-02-08. Urban Aeronautics holds the Fancraft / fuselage-internal-rotor patent family (US 7,789,342 et seq., filed early 2000s).
- **ip status**: patented
- **prior art notes**: Urban Aeronautics CityHawk / Cormorant establishes Israeli prior-art lineage for ducted-fan internal-rotor VTOL ('Fancraft'). The fuselage-internal lift-fan architecture is uncommon and relatively narrowly patented by Urban Aeronautics. Cormorant (military cargo variant) completed Israeli Defense Forces evaluation 2016. Establishes prior art for: (1) fuselage-internal ducted lift fan, (2) cascade-vane deflection for attitude control in lieu of differential rotor thrust, (3) compact urban-VTOL form factor without exposed rotors. Anticipates modern claims around safety-margin-improvement via internal rotors.

## e-volo VC1 (Volocopter precursor) (2011-10-21)

- **id**: `volocopter-vc1`
- **corpus**: private
- **creator**: e-volo GmbH (later Volocopter GmbH)
- **disclosure**: e-volo / Stephan Wolf, Thomas Senkel, Alexander Zosel: first manned multicopter flight, 2011-10-21 at Karlsruhe-Forchheim airfield; documented in DLR aviation news and academic press.
- **ip status**: patented
- **prior art notes**: The e-volo VC1 is the first manned electric multicopter to achieve flight, predating EHang, Joby S2/S4, and Volocopter VoloCity. Establishes prior art for: (1) electric manned multicopter passenger air-mobility architecture, (2) sixteen-rotor circular lift configuration with differential-thrust attitude control, (3) the underlying Volocopter patent family (DE102010032217 and continuations). Anticipates virtually all current commercial electric multirotor air-taxi claims (EHang EH216, Volocopter VoloCity, Hyundai Supernal multirotor configurations).

## PAL-V Liberty (2012-04-01)

- **id**: `pal-v-liberty`
- **corpus**: private
- **creator**: PAL-V International B.V. (Raamsdonksveer, Netherlands)
- **disclosure**: PAL-V One prototype first flight 2012-04-01; PAL-V Liberty production design unveiled 2017-03-07 at Geneva Motor Show; received EASA Type Certificate Part 27 (CS-27) for autogyro mode 2024-04-29. PAL-V founded 2008 by John Bakker.
- **ip status**: patented
- **prior art notes**: PAL-V Liberty is the Netherlands' lead drive+fly transformer — architecturally distinct from Slovak peers (Klein/AeroMobil) by using autogyro lift rather than fixed-wing flight. Holds EASA Type Certificate Part 27 (autogyro mode), 2024-04-29 — the world's first type-certified flying car under autogyro classification. Direct architectural descendant of Cierva autogyro (1923) in road-legal passenger form factor.

## Zuri eVTOL (2017-03)

- **id**: `zuri-evtol`
- **corpus**: private
- **creator**: Zuri s.r.o (Prague, Czech Republic)
- **disclosure**: Zuri founded 2017-03 by Michal Illich, Stanislav Saling, and Daniel Hadacek; first sub-scale prototype publicly demonstrated 2018-09; full-scale Zuri 2.0 prototype unveiled 2021-10-12 in Pisek and reached first hover 2023-09-22. EASA Special Condition VTOL certification dialogue 2022 onward.
- **ip status**: patented
- **prior art notes**: Zuri eVTOL is the lead Czech (and Central European) commercial eVTOL — hybrid-electric lift+cruise distinct from pure-battery competitors in its 700 km range targeting. Establishes Czech prior-art lineage for hybrid-electric eVTOL and adds to the global hybrid-eVTOL prior-art base alongside Honda eVTOL, AMSL Aero Vertiia, and Elroy Air Chaparral.

## AeroMobil 4.0 (2017-04-20)

- **id**: `aeromobil-4-0`
- **corpus**: private
- **creator**: AeroMobil s.r.o (Bratislava, Slovakia)
- **disclosure**: AeroMobil 4.0 publicly unveiled 2017-04-20 at Top Marques Monaco; predecessor AeroMobil 3.0 first flew 2014-10-29 (with crash 2015-05-08, pilot Stefan Klein survived; Klein subsequently founded Klein Vision). AeroMobil holds patents on retractable-wing roadable aircraft.
- **ip status**: patented
- **prior art notes**: AeroMobil 4.0 is Slovakia's other major drive+fly transformer disclosure (Klein departed AeroMobil after the 3.0 crash and founded Klein Vision). Establishes parallel Slovak prior-art lineage with hybrid-parallel powerplant — distinct from Klein Vision's pure-combustion approach. Combined with klein-vision-aircar, places drive+fly transformer prior art comprehensively in Slovak hands. Anticipates ASKA A5 and all subsequent drive+fly transformer claims.

## Wingcopter 198 (2017-04-26)

- **id**: `wingcopter-198`
- **corpus**: private
- **creator**: Wingcopter GmbH (Weiterstadt, Germany)
- **disclosure**: Wingcopter founded 2017-04-26; Wingcopter 178 first commercial flights 2018-09 (vaccine delivery to Vanuatu islands with UNICEF); Wingcopter 198 production-design unveiled 2020-04-21. EU type certification (CS-LURS / EASA Special Condition) in process. Wingcopter holds the Tilt-Rotor Mechanism patent family (EP3260370, US10913529).
- **ip status**: patented
- **prior art notes**: Wingcopter 198 is Germany's lead unmanned tilt-rotor cargo eVTOL — operational since 2018 (medical delivery to Pacific islands with UNICEF). Establishes prior art for: (1) small-airframe tilt-rotor cargo eVTOL with single-axis tilt mechanism (Wingcopter Tilt-Rotor Mechanism patent family), (2) the cargo / payload-delivery use case for tilt-rotor eVTOL distinct from passenger air taxi. Anticipates cargo eVTOL claims asserting novelty over single-axis tilt actuation.

## ASKA A5 (2018)

- **id**: `aska-a5`
- **corpus**: private
- **creator**: ASKA / NFT Inc (Mountain View, California / Nagoya, Japan)
- **disclosure**: ASKA / NFT Inc founded 2018 by Guy Kaplinsky and Maki Kaplinsky; A5 production-design unveiled at CES 2023 (2023-01-04); FAA Special Airworthiness Certificate (Experimental) granted 2023-06-29 for flight testing. NHTSA-approved street-legal road operation pending.
- **ip status**: patented
- **prior art notes**: ASKA A5 is the leading drive+fly transformer eVTOL with documented FAA experimental-category certification. Establishes prior art for: (1) folding-wing tilt-rotor transformer architecture, (2) hybrid-electric powerplant for transformer range extension, (3) dual-certification basis (FAA + NHTSA road-legal). Anticipates: PAL-V Liberty, AeroMobil 4.0, Klein Vision AirCar, and any modern drive+fly patent claim.

## Airbus A^3 Vahana (2018-01-31)

- **id**: `airbus-vahana`
- **corpus**: private
- **creator**: Acubed (Airbus Silicon Valley) / Airbus SAS
- **disclosure**: Airbus A^3 Vahana sub-scale demonstrator first untethered hover 2018-01-31 at Pendleton OR (Acubed test site); first transition flight 2018-05-15. Vahana flight-test program completed 2019-11 with 138 successful flights. Acubed published Vahana technical papers and design data openly.
- **ip status**: patented
- **prior art notes**: Airbus Vahana is the first fully-autonomous tilt-wing eVTOL to achieve transition flight (2018) — a distinct architectural achievement combining tilt-wing geometry with BLDC distributed electric propulsion and full-autonomy control, all flying 138+ missions in 2018-2019. Establishes prior art for: (1) tilt-wing passenger eVTOL with eight-rotor configuration, (2) full-autonomy transition control across the conversion corridor, (3) production-ready electric tilt-wing flight-control architecture. Acubed published Vahana data openly, putting comprehensive engineering disclosure in the public domain.

## EHang EH216-S (2018-02-05)

- **id**: `ehang-eh216`
- **corpus**: private
- **creator**: EHang Holdings
- **disclosure**: EHang 184 / 216 platform first publicly disclosed at CES 2016; EH216 designation first used 2018-02-05 in EHang corporate filings; EH216-S type certificate granted by CAAC 2023-10-13 (TC No. ETC-G-2023-101). Production certificate granted 2024-04-07.
- **ip status**: patented
- **prior art notes**: EHang EH216-S is the first eVTOL to receive a full type certificate from a major civil aviation authority (CAAC, 2023-10-13). The TC documentation is publicly available and constitutes a comprehensive engineering disclosure under SC-VTOL-like framework. Establishes commons-grade disclosure of: (1) eight-coaxial-pair 16-rotor lift architecture, (2) production autonomous-passenger eVTOL flight management system, (3) the CAAC SC-VTOL certification basis itself (the regulation and applied airworthiness criteria are public). Together with volocopter-vc1, places multirotor passenger eVTOL architecture comprehensively in the public domain as of 2018.

## Wisk Aero Cora / Gen 6 (2018-03-13)

- **id**: `wisk-cora`
- **corpus**: private
- **creator**: Wisk Aero LLC (Boeing / Kitty Hawk joint venture)
- **disclosure**: Cora aircraft publicly unveiled 2018-03-13 by Kitty Hawk; first untethered hover earlier in 2017 (test campaign in New Zealand); Wisk Aero JV with Boeing announced 2019-12-19; Gen 6 production design unveiled 2022-10-03; Boeing acquired Kitty Hawk's interest 2023-05, making Wisk a Boeing subsidiary.
- **ip status**: patented
- **prior art notes**: Wisk Cora / Gen 6 is the leading US autonomous (no on-board pilot) passenger eVTOL — distinct architectural commitment to autonomy from Joby, Archer, Beta. Lift+cruise architecture with 12+1 propulsor count. Establishes US prior-art lineage for autonomous-passenger commercial lift+cruise eVTOL targeting FAA Part 23 / Special Conditions.

## EmbraerX eVTOL concept (2018) (2018-05-09)

- **id**: `embraerx-evtol-concept`
- **corpus**: private
- **creator**: EmbraerX (Embraer S.A. internal venture)
- **disclosure**: Embraer publicly unveiled its eVTOL air taxi concept design at the Uber Elevate Summit, Los Angeles, 2018-05-09. EmbraerX (Embraer's internal venture launched 2017-10) led the design. The 2018 concept preceded Eve UAM Solutions (Embraer subsidiary, 2020-10-08) and Eve Holding spinoff (NYSE: EVEX SPAC merger, 2022-05-09).
- **ip status**: patented
- **prior art notes**: EmbraerX 2018 is the original Brazilian disclosure of the lift+cruise architecture that subsequently became Eve Air Mobility's production design. Establishes Brazilian / Latin American prior-art lineage two years earlier than the 2020 Eve Air Mobility entity. The Uber Elevate Summit 2018 unveiling makes this a publicly-dated Embraer corporate disclosure with documented engineering depth in subsequent Embraer technical materials. Combined with eve-air-mobility (2020), provides a multi-year Embraer lineage for the 8+1 lift+cruise architecture.

## Pivotal Helix (formerly Opener BlackFly) (2018-07-12)

- **id**: `pivotal-blackfly`
- **corpus**: private
- **creator**: Opener Inc / Pivotal LLC
- **disclosure**: Opener / BlackFly publicly unveiled 2018-07-12 with first flight video and FAA Part 103 ultralight categorization; subsequent customer deliveries 2022 (Pivotal Helix branding 2023).
- **ip status**: patented
- **prior art notes**: Pivotal Helix (formerly Opener BlackFly) is a single-pilot tail-sitter eVTOL operating under FAA Part 103 ultralight rules — the first commercially-delivered eVTOL in the U.S. market. Architecturally a tail-sitter (descended from XFY-1 Pogo, 1954) with eight distributed electric rotors. Establishes prior art for: (1) eight-rotor tail-sitter eVTOL geometry, (2) Part 103 ultralight-class commercial eVTOL deployment basis, (3) the design tradeoff of pilot pitch reorientation as an alternative to tilt-rotor or tilt-wing transition mechanisms.

## Pyka Pelican Cargo (2018-08)

- **id**: `pyka-pelican`
- **corpus**: private
- **creator**: Pyka (Oakland, California)
- **disclosure**: Pyka founded 2018; Egret (predecessor agricultural eVTOL) operational since 2019; Pelican Cargo unveiled 2022-06-21; FAA Part 137 ag operations approval (Pelican Spray) 2023-04. Pyka's autonomy stack documented in open technical white papers.
- **ip status**: patented
- **prior art notes**: Pyka Pelican is the leading US autonomous cargo eVTOL targeting agricultural and middle-mile logistics. Establishes prior art for: (1) autonomous lift+cruise cargo eVTOL operating under Part 137 / Part 23, (2) electric agricultural-spray eVTOL (Pelican Spray variant operational since 2023). Distinct architectural commitment from passenger eVTOL: prioritizes payload, range, and short-strip operation over hover endurance.

## Jetson ONE (2018-09)

- **id**: `jetson-one`
- **corpus**: private
- **creator**: Jetson AB (Italy / Sweden joint operation)
- **disclosure**: Jetson AB founded 2018-09 by Tomasz Patan (Polish-Swedish) and Peter Ternström (Swedish); Jetson ONE design unveiled 2020-04-21; first manned flight 2020-09; first customer deliveries 2023-09.
- **ip status**: patented
- **prior art notes**: Jetson ONE is the leading consumer ultralight-class single-seat eVTOL — the Swedish/Italian/Polish realization of the open-frame multirotor design originally disclosed by Curtiss-Wright VZ-7 (1958). Operates under FAA Part 103 ultralight rules with no pilot license required. Establishes Northern European prior-art lineage for consumer-grade ultralight eVTOL with open-rotor architecture and rotor-failure reconfiguration.

## Pegasus Vertical Business Jet (2018-11-08)

- **id**: `pegasus-universal-aerospace`
- **corpus**: private
- **creator**: Pegasus Universal Aerospace (Johannesburg, South Africa)
- **disclosure**: Pegasus Vertical Business Jet design publicly unveiled 2018-11-08 at Aero South Africa; subsequent design refinements 2020–2024. Pegasus Universal Aerospace founded 2017 by Reza Mia. South African Civil Aviation Authority engagement on certification framework 2021 onward.
- **ip status**: patented
- **prior art notes**: Pegasus Vertical Business Jet is South Africa's lead commercial VTOL design — distinct architectural commitment to executive-jet operations (2,200 km range, 400 kt cruise) with VTOL hover capability. Establishes African continental prior-art lineage for commercial VTOL business aviation distinct from urban air taxi. Architecturally similar to Lockheed Martin / Aurora LightningStrike (XV-24A, US military 2016) in fuselage-internal lift fan + cruise jet topology.

## SkyDrive SD-05 (2018-12)

- **id**: `skydrive-sd-05`
- **corpus**: private
- **creator**: SkyDrive Inc
- **disclosure**: SkyDrive SD-03 (precursor demonstrator) public manned flight 2020-08-25 at Toyota Test Field; SD-05 production design unveiled 2021-09; Japan Civil Aviation Bureau type-certification application accepted 2021-10. SkyDrive founded 2018-12 (incorporation date), spinning out from CARTIVATOR volunteer eVTOL project (founded 2012).
- **ip status**: patented
- **prior art notes**: SkyDrive SD-05 is Japan's lead passenger eVTOL, with Japan Civil Aviation Bureau type-certification application accepted 2021-10. The 12-motor coaxial-pair architecture is similar to EHang EH216-S; the program establishes Japanese prior-art lineage for multirotor passenger eVTOL and the JCAB SC-VTOL-equivalent certification approach. Originated in the volunteer CARTIVATOR project (2012), one of the earliest organized open-development eVTOL efforts.

## Joby Aviation S4 (2018-12-20)

- **id**: `joby-s4`
- **corpus**: private
- **creator**: Joby Aviation
- **disclosure**: Joby S4 unveiling and first flight: Joby first publicly disclosed S4 prototype 2018-12-20 (Joby press release); first untethered transition flight 2017-08 (predecessor S2); S4 Production Prototype first transition flight reported in Joby Aviation S-1 SEC filing 2020-08, full disclosure in 10-K filings 2021–2025.
- **ip status**: patented
- **prior art notes**: The Joby S4 is the lead commercial tilt-rotor electric eVTOL. Direct architectural descendant of bell-xv-15 (1977) and v-22-osprey (1989) — Joby's tilt geometry, conversion corridor, and gimbaled prop-rotor topology are classical tilt-rotor architecture with electric distributed propulsion substituted for cross-shafted turboshaft. Establishes prior art for: (1) six-rotor tilt-rotor with stop-in-cruise props, (2) BLDC direct-drive tilt-rotor propulsion, (3) Part 23 SVO certification basis. Joby's patent estate (US 10,994,841 et seq.) covers specific implementations but is anticipated on the architectural level by XV-15 and V-22 disclosures.

## Bell Nexus 4EX (2019-01-07)

- **id**: `bell-nexus-4ex`
- **corpus**: private
- **creator**: Bell (Textron Inc)
- **disclosure**: Bell Nexus design publicly unveiled 2019-01-07 at CES Las Vegas; Nexus 4EX revised four-rotor variant unveiled 2020-01-07. Program wound down circa 2022; design materials and filings remain in the public record.
- **ip status**: patented
- **prior art notes**: Bell Nexus is one of the Uber-Elevate-era US passenger eVTOL concepts (2019). Although the program wound down, the public design disclosures remain prior art for: (1) hybrid-electric tilting-ducted-fan eVTOL architecture, (2) Bell's specific tilt-duct geometry distinct from Joby's open-rotor tilt-rotor approach. Establishes additional US prior-art lineage for tilt-duct passenger eVTOL (with bell-x-22 from 1966).

## Elroy Air Chaparral C1 (2019-01-30)

- **id**: `elroy-air-chaparral`
- **corpus**: private
- **creator**: Elroy Air Inc (San Francisco)
- **disclosure**: Elroy Air founded 2016 by David Merrill and Kofi Asante; sub-scale Chaparral demonstrator publicly unveiled 2019-01-30; full-scale C1 first hover flight 2023-11-12 at Camarillo, CA. Air Force AFWERX / USAF Agility Prime contracts 2021-09 onward.
- **ip status**: patented
- **prior art notes**: Elroy Air Chaparral establishes prior art for: (1) hybrid-electric (turbine-genset + battery) cargo eVTOL, distinct from pure-battery designs by extending range to 500+ km, (2) modular swappable cargo-pod architecture decoupled from aircraft turnaround. Hybrid powerplant anticipates similar claims on series-hybrid eVTOL propulsion topology.

## Lilium Jet (7-seat) (2019-05-16)

- **id**: `lilium-jet`
- **corpus**: private
- **creator**: Lilium GmbH
- **disclosure**: Lilium Jet 5-seat prototype unveiled and first hover flight 2019-05-16 at Manching; 7-seat production design unveiled 2021-03-30. Disclosures continued through Lilium SPAC merger Form S-4 2021-09 and subsequent NASDAQ filings until bankruptcy 2024-10.
- **ip status**: patented
- **prior art notes**: Lilium Jet establishes prior art for the high-multiplicity ducted-fan-array eVTOL: 36 small embedded ducted fans tilting in flap-segment groupings to provide both lift and cruise. Architecturally a hyper-distributed extension of Bell X-22 (4 tilt-ducts) and Doak VZ-4 (2 tilt-ducts). Although Lilium filed for bankruptcy in October 2024, the patent estate (now in receivership / likely auctioned) covers specific implementations of the 36-fan ducted-array geometry and EASA SC-VTOL certification basis approaches. The fundamental architecture (multiple ducted fans in a tilting flap arrangement) is anticipated by Bell X-22 (1966).

## Volocopter VoloCity (2019-08-14)

- **id**: `volocopter-volocity`
- **corpus**: private
- **creator**: Volocopter GmbH
- **disclosure**: VoloCity production-design unveiling 2019-08-14 at Helsinki ITS World Congress; precursor VC-200 first manned flight 2013-11-17; first public manned demo at Singapore 2019-10-22. EASA SC-VTOL certification process actively pursued; targeted operations Paris 2024 / 2026 commercial rollouts.
- **ip status**: patented
- **prior art notes**: Volocopter VoloCity is the production design descending from e-volo VC1 (2011, first manned multicopter flight). 18-rotor circular-ring multirotor architecture, EASA SC-VTOL certification basis. Establishes the German prior-art lineage from e-volo through Volocopter for circular-ring multirotor passenger eVTOL — foundational and predates EHang in manned-flight precedence.

## Beta Technologies Alia-250 (2020-03-10)

- **id**: `beta-alia-250`
- **corpus**: private
- **creator**: Beta Technologies
- **disclosure**: Beta Technologies / Kyle Clark publicly unveiled Alia-250 design 2020-03-10; first hover flight 2020-05; first full transition flight 2021-04; multiple cross-country flights 2022–2024 publicly documented.
- **ip status**: patented
- **prior art notes**: Beta Alia-250 is the canonical commercial lift+cruise eVTOL: lift rotors stop and shut down in cruise, with a separate pusher providing forward propulsion. Architecturally simpler than tilt-rotor (no transition envelope coupling between lift and cruise), at cost of cruise drag from stopped lift rotors. Establishes prior art for: (1) production-scale lift+cruise architecture with mode-shutdown transition, (2) coaxial lift-pair geometry with single pusher cruise. Cited extensively by NASA Langley as the lift+cruise reference design.

## Manta Aircraft ANN2 (2020-04)

- **id**: `manta-aircraft-ann2`
- **corpus**: private
- **creator**: Manta Aircraft S.A. (Lugano, Switzerland / Varese, Italy)
- **disclosure**: Manta Aircraft ANN2 design publicly unveiled April 2020 at AERO Friedrichshafen; sub-scale prototype hover testing 2021. Manta Aircraft founded 2018 by Lucas Marchesini (Italian-Swiss aerospace engineer).
- **ip status**: patented
- **prior art notes**: Manta Aircraft ANN2 is the lead Italian-Swiss commercial eVTOL — hybrid-electric tilt-rotor with twin-fuselage geometry. Adds Italian prior-art lineage for hybrid-electric eVTOL alongside Leonardo AW609 (production tilt-rotor) and complements the Slovak (Klein Vision, AeroMobil) and Dutch (PAL-V) drive+fly Central European base.

## Klein Vision AirCar (2020-10)

- **id**: `klein-vision-aircar`
- **corpus**: private
- **creator**: Klein Vision s.r.o (Nitra, Slovakia)
- **disclosure**: Klein Vision AirCar Prototype 1 first flight test 2020-10; first inter-airport flight 2021-06-28 (Nitra to Bratislava). Slovak Transport Authority issued Certificate of Airworthiness 2022-01-26 — the world's first roadable-aircraft type certificate. Klein Vision founded by Stefan Klein.
- **ip status**: patented
- **prior art notes**: Klein Vision AirCar holds the world's first type-certified roadable-aircraft certificate (Slovak Transport Authority, 2022-01-26). Establishes Slovak prior-art lineage and certified-product anchor for the drive+fly transformer category. Not VTOL but architecturally adjacent — many drive+fly eVTOL designs (ASKA A5, AeroMobil 4.0) build on the same retractable-wing transformer architecture pioneered in road-legal aviation by Klein.

## Eve Air Mobility eVTOL (2020-10-08)

- **id**: `eve-air-mobility`
- **corpus**: private
- **creator**: Eve Holding Inc (Embraer S.A. spinoff)
- **disclosure**: Eve UAM Solutions launched as Embraer subsidiary 2020-10-08; spun off as standalone Eve Holding via SPAC merger 2022-05-09 (NYSE: EVEX). Aircraft design publicly unveiled 2022; first prototype unveiled 2024.
- **ip status**: patented
- **prior art notes**: Eve Air Mobility is Brazil's lead commercial eVTOL, backed by Embraer's 100+-year aerospace heritage. The 8+1 lift+cruise architecture is architecturally similar to Beta Alia and AutoFlight Prosperity I; establishes Brazilian / Latin American prior-art lineage for commercial lift+cruise eVTOL. Eve has the deepest commercial aerospace certification experience among any eVTOL company by virtue of Embraer parentage.

## AMSL Aero Vertiia (2021-03)

- **id**: `amsl-vertiia`
- **corpus**: private
- **creator**: AMSL Aero Pty Ltd (Bankstown, Australia)
- **disclosure**: AMSL Aero Vertiia design publicly unveiled March 2021; sub-scale prototype hover testing 2022; first hover flight 2023-02-15. AMSL Aero founded 2017 by Andrew Moore (former CSIRO and Boeing engineer) and Siobhan Lyndon. Targeted at hydrogen-fuel-cell-powered eVTOL ambulance and regional connectivity missions.
- **ip status**: patented
- **prior art notes**: AMSL Aero Vertiia is Australia's lead commercial eVTOL with a distinctive commitment to hydrogen-fuel-cell propulsion for 1,000 km range — addressing the energy-density limitation of pure-battery eVTOL. Establishes Australian prior-art lineage for hydrogen-eVTOL and for long-range regional eVTOL distinct from short-range urban air taxi. Anticipates other hydrogen-fuel-cell eVTOL claims (e.g., Joby's post-acquisition H2 program, Airbus ZEROe rotorcraft).

## Archer Aviation Midnight (2021-06-10)

- **id**: `archer-midnight`
- **corpus**: private
- **creator**: Archer Aviation
- **disclosure**: Archer Aviation S-1 SEC filing 2021-06-10; Archer Midnight design publicly unveiled 2022-11-16; Maker demonstrator first hover flight 2021-12; first full transition 2023-06.
- **ip status**: patented
- **prior art notes**: Archer Midnight is a hybrid lift+cruise / tilt-rotor architecture with six tilting and six lift-only propellers. Architecturally descends from the NASA GL-10 DEP tilt-wing concept and the XV-15 tilt-rotor, with the lift+cruise split providing lower hover-prop disk loading at the cost of cruise drag from idle lift props. Disclosures in SEC filings make this a commons-grade entry. Establishes prior art for: (1) 6+6 hybrid tilt-and-lift-only DEP architecture, (2) feathering cruise props with fixed-cruise disk.

## XPENG AeroHT X2 (2021-07-16)

- **id**: `aeroht-xpeng-x2`
- **corpus**: private
- **creator**: AeroHT (XPENG flying car subsidiary)
- **disclosure**: XPENG Voyager X2 publicly unveiled 2021-07-16 at XPENG Tech Day; first untethered manned flight 2022-10-10 at Dubai. AeroHT subsequently unveiled X3 (2023) and the modular Land Aircraft Carrier (2024). AeroHT holds Chinese patents on coaxial multirotor and modular drive+fly architecture.
- **ip status**: patented
- **prior art notes**: AeroHT (XPENG flying car subsidiary) is one of three lead Chinese passenger eVTOL programs (with EHang and AutoFlight). The X2 establishes Chinese prior art for coaxial-pair multirotor passenger eVTOL with autonomous + pilot-override flight management. AeroHT's subsequent X3 and modular Land Aircraft Carrier (2024) extend to drive+fly transformer geometry.

## Geely Aerofugia AE200 (2021-09-14)

- **id**: `geely-aerofugia-ae200`
- **corpus**: private
- **creator**: Aerofugia (Geely Holding Group eVTOL subsidiary)
- **disclosure**: Geely Holding Group launched Aerofugia subsidiary 2021-09-14 in Chengdu; AE200 design publicly unveiled at Beijing Air Show 2022-02-10; sub-scale prototype hover 2023-04. Geely also acquired Terrafugia (US) 2017-11 and uses combined IP base for AE200.
- **ip status**: patented
- **prior art notes**: Geely Aerofugia AE200 is China's third major commercial passenger eVTOL (with EHang and AutoFlight). Distinctive: Geely's parallel ownership of Terrafugia (US flying car company since 2017) provides cross-Pacific patent integration. Establishes additional Chinese tilt-rotor prior-art lineage alongside TCab E20.

## Airbus CityAirbus NextGen (2021-09-21)

- **id**: `airbus-cityairbus-nextgen`
- **corpus**: private
- **creator**: Airbus Helicopters (Donauwörth, Germany) / Airbus Defence and Space
- **disclosure**: Airbus CityAirbus NextGen design publicly unveiled 2021-09-21 at Airbus Summit; first scaled prototype hover 2024-09. EASA SC-VTOL type-certification process initiated 2022. Predecessor CityAirbus demonstrator first hover 2019-05-03.
- **ip status**: patented
- **prior art notes**: Airbus CityAirbus NextGen is the production-track lift+cruise successor to the Vahana research program. Establishes German industrial prior-art lineage for production-scale lift+cruise passenger eVTOL with V-strut lift-rotor mounting geometry distinct from boom-mounted competitors (Beta Alia, Eve, Wisk). Airbus's industrial certification scale and EASA insider position make this a particularly important commons-grade entry.

## Vertical Aerospace VX4 (2021-09-29)

- **id**: `vertical-vx4`
- **corpus**: private
- **creator**: Vertical Aerospace Ltd (Bristol, United Kingdom)
- **disclosure**: Vertical Aerospace VX4 unveiled 2021-09-29 at SPAC announcement / investor presentation; first tethered hover 2022-09-26; first untethered transition 2024-12. SPAC merger with Broadstone Acquisition (NYSE: EVTL) completed 2021-12. Lead investors include Microsoft / Avolon / American Airlines / Honeywell / Rolls-Royce.
- **ip status**: patented
- **prior art notes**: Vertical Aerospace VX4 is the United Kingdom's lead commercial eVTOL — the post-Hawker British vectored/tilt VTOL inheritance translated into electric propulsion. The 4+4 tilt-and-lift hybrid is architecturally between Joby S4 (6 tilt) and Archer Midnight (6+6 hybrid). Establishes UK prior-art lineage for commercial tilt-rotor eVTOL; Rolls-Royce propulsion subsystem involvement provides direct industrial-scale supplier coverage.

## Honda eVTOL (2021-09-30)

- **id**: `honda-evtol`
- **corpus**: private
- **creator**: Honda Motor Company / Honda Aircraft Company
- **disclosure**: Honda Motor Company eVTOL program publicly disclosed 2021-09-30 at 'Honda Dream Loop' announcement; design materials and target specifications subsequently disclosed in Honda investor briefings 2022–2024. Targeted commercial operation 2030.
- **ip status**: patented
- **prior art notes**: Honda eVTOL establishes prior art for hybrid-turbine-electric passenger eVTOL — Honda's specific architecture decision is to use a gas-turbine genset (leveraging HondaJet experience) for range extension. Anticipates other turbine-hybrid eVTOL claims (Elroy Air Chaparral, AMSL Aero Vertiia variants).

## AIR ONE (eVTOL) (2021-10-04)

- **id**: `air-one`
- **corpus**: private
- **creator**: AIR Mobility Ltd (Pardes Hanna, Israel)
- **disclosure**: AIR ONE publicly unveiled 2021-10-04 in San Francisco; first untethered manned hover flight 2023-06-19 at AIR Pardes Hanna test site, Israel. AIR Mobility founded by Rani Plaut and Chen Rosen, 2018.
- **ip status**: patented
- **prior art notes**: AIR ONE is Israel's lead consumer-grade eVTOL — distinct from CityHawk (commercial ducted-fan) by addressing the personal-recreational segment. Lift+cruise architecture targeting Part 23 certification with consumer operability emphasis. Establishes Israeli prior-art lineage for consumer/recreational eVTOL distinct from passenger air taxi.

## AutoFlight Prosperity I (2021-12-13)

- **id**: `autoflight-prosperity-i`
- **corpus**: private
- **creator**: AutoFlight (Shanghai)
- **disclosure**: AutoFlight Prosperity I publicly unveiled 2021-12-13; first untethered hover flight 2022-04; full-scale prototype transition flight 2023-02-23 at Kunshan; cross-Pearl River Delta demonstration flight Hong Kong → Macau 2024-04-29. AutoFlight founded by Tian Yu (former co-founder of EHang).
- **ip status**: patented
- **prior art notes**: AutoFlight Prosperity I is the leading Chinese lift+cruise eVTOL — architectural sibling to Beta Alia-250 with eight rather than four lift rotors. The 250 km Hong Kong-Macau demonstration flight (2024-04-29) is the longest eVTOL flight publicly documented as of mid-2024. Establishes Chinese prior-art lineage for lift+cruise architecture and supports EASA SC-VTOL certification basis dual-track with EHang's CAAC certification.

## ePlane Company e200 (2022-08)

- **id**: `eplane-company-e200`
- **corpus**: private
- **creator**: The ePlane Company (IIT Madras spinout)
- **disclosure**: The ePlane Company e200 unveiled 2022-08; first sub-scale prototype hover flight 2022-12; full-scale prototype rolled out 2023-09 at IIT Madras Research Park. Founded 2017 by Prof. Satya Chakravarthy. Awarded Anjani Mashelkar Inclusive Innovation Award 2023.
- **ip status**: patented
- **prior art notes**: ePlane e200 is India's lead commercial eVTOL — IIT Madras research spinout with explicit design constraint for compact urban Indian airspace. Establishes Indian prior-art lineage for commercial lift+cruise eVTOL and the design philosophy of compact-footprint operation in dense urban environments. Targeted at DGCA (Directorate General of Civil Aviation, India) certification.

## TCab Tech E20 (2022-12-07)

- **id**: `tcab-tech-e20`
- **corpus**: private
- **creator**: TCab Tech (Shanghai TCab)
- **disclosure**: TCab Tech E20 sub-scale technology demonstrator first transition flight 2022-12-07 at Tianjin; full-scale E20 prototype unveiled 2023-09-13. TCab founded 2021 in Shanghai by Yon Wui Ng; technical leadership from former Volocopter and Lilium engineers.
- **ip status**: patented
- **prior art notes**: TCab Tech E20 is China's lead tilt-rotor passenger eVTOL — architectural sibling to Joby S4 with the same 4+2 tilt-rotor configuration. Establishes Chinese-lineage prior art for the tilt-rotor electric eVTOL category, ensuring the architectural pattern is disclosed across at least four geographic prior-art bases (US, EU, China, Italy).

## DJI FlyCart 30 (2023-08-16)

- **id**: `dji-flycart-30`
- **corpus**: private
- **creator**: SZ DJI Technology Co Ltd (Shenzhen)
- **disclosure**: DJI FlyCart 30 publicly unveiled 2023-08-16 in Shenzhen; CAAC type certification application 2023; commercial deliveries to Chinese and international markets 2024. DJI is the world's largest drone manufacturer and holds an extensive multirotor patent estate.
- **ip status**: patented
- **prior art notes**: DJI FlyCart 30 is the entry of the world's largest drone manufacturer into the heavy-cargo eVTOL category. DJI's massive patent estate and operational scale (millions of multirotor flights/day globally) constitute foundational prior-art coverage for: (1) coaxial-pair multirotor manufacturing at scale, (2) autonomous multirotor cargo delivery, (3) consumer-priced multirotor architecture migration to commercial cargo class. Establishes Chinese prior-art lineage for heavy-payload multirotor cargo eVTOL with explicit Beyond Visual Line of Sight (BVLOS) operational basis.

## Hyundai Supernal S-A2 (2024-01-09)

- **id**: `hyundai-supernal-sa2`
- **corpus**: private
- **creator**: Supernal LLC (Hyundai Motor Group eVTOL subsidiary)
- **disclosure**: Hyundai Supernal S-A2 unveiled at CES 2024 (Las Vegas), 2024-01-09. Predecessor S-A1 design unveiled at CES 2020 (2020-01-07). Supernal LLC incorporated under Hyundai Motor Group, headquartered in Washington DC with engineering in Irvine CA, but the design lineage and corporate ownership are South Korean.
- **ip status**: patented
- **prior art notes**: Hyundai Supernal S-A2 is Korea's lead commercial eVTOL program, backed by Hyundai Motor Group's automotive industrial scale. The 4+4 tilt-rotor configuration is architecturally between Joby S4 (4+2) and tilt-wing designs. Establishes Korean prior-art lineage for tilt-rotor commercial eVTOL; targets FAA Part 23 certification and 2028 commercial operation.

## XPENG AeroHT Land Aircraft Carrier (2024-04-04)

- **id**: `xpeng-aeroht-modular`
- **corpus**: private
- **creator**: AeroHT (XPENG flying car subsidiary)
- **disclosure**: XPENG AeroHT Land Aircraft Carrier publicly unveiled 2024-04-04 at Beijing Auto Show; production target 2026. Combines a road-legal 6x6 ground vehicle ('Mothership') containing a fold-out manned eVTOL drone.
- **ip status**: patented
- **prior art notes**: XPENG AeroHT Land Aircraft Carrier is the most ambitious modular drive+fly transformer architecture publicly disclosed: a separate ground vehicle that carries and deploys a manned eVTOL. Establishes Chinese prior-art lineage for modular vehicle-eVTOL architectures, distinct from integrated transformer-eVTOL designs (ASKA A5, AeroMobil) where one vehicle physically transforms. Anticipates future modular-carrier patent filings.
